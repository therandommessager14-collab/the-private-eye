# Nile News — V2 Visual Design

A polished static visual prototype for NILE NEWS: an anonymous, school-friendly campus gossip/social-buzz publication.

## Visual identity
- Deep burgundy/red, warm white/cream, black and subtle silver
- Elegant editorial serif headlines
- Clean sans-serif navigation and body copy
- Thin rules, spacious magazine-style layout
- Red NILE ALERT treatment and dark editorial sections
- Responsive for phones and tablets

## Important
This is still a visual/static prototype. The submission form does not actually send or store messages. Before public launch, connect it to a secure private backend with spam protection, moderation, authentication, and private email/database handling.

For free hosting, GitHub Pages can publish the static HTML/CSS/JS from a repository. Do not place private submissions or admin credentials in a public repository.
